import streamlit as st
import pandas as pd
import numpy as np
import joblib  # For loading the saved model
from sklearn.preprocessing import StandardScaler

# Load your pre-trained model and scaler
@st.cache_resource
def load_model_and_scaler():
    model = joblib.load("C:\\Users\\User\\OneDrive\\Desktop\\New folder\\ml project\\knn_model.sav")
    scaler = joblib.load("C:\\Users\\User\\OneDrive\\Desktop\\New folder\\ml project\\scalar.sav")
    return model, scaler

# Load the model and scaler
model, scaler = load_model_and_scaler()

# App title
st.title("Weather Classification App 🌤️")

# Instructions
st.markdown(
    """
    This app predicts the weather class (e.g., Sunny, Rainy, Cloudy) based on input features.
    Fill in the values below and click 'Predict' to see the result.
    """
)

# Input features
temperature = st.number_input("Temperature (°C)", value=25.0, step=0.1)
humidity = st.number_input("Humidity (%)", value=60.0, step=0.1)
wind_speed = st.number_input("Wind Speed (km/h)", value=10.0, step=0.1)
precipitation= st.number_input("Precipitation (%)", value=85.0, step=0.1)
cloud_cover = st.number_input("Cloud Cover", value=3.0, step=0.1)
Atmospheric_Pressure = st.number_input("Atmospheric Pressure", value=1013.0, step=0.1)
uv_index = st.number_input("UV Index", value=2.0, step=0.1)
season = st.number_input("Season", value=3.0, step=0.1)
visibility = st.number_input("Visibility (km)", value=3.5, step=0.1)
location = st.number_input("Location", value=1.0, step=0.1)

# Create a button for prediction
if st.button("Predict"):
    # Prepare the input data
    input_data = np.array([[temperature, humidity, wind_speed, precipitation, cloud_cover,Atmospheric_Pressure, uv_index, season, visibility, location]])
    
    # Scale the input data
    scaled_data = scaler.transform(input_data)
    
    # Make a prediction
    prediction = model.predict(scaled_data)
    
    # Display the result
    st.subheader("Prediction Result:")
    st.write(f"The predicted weather class is: **{prediction[0]}**")

# Add a footer
st.markdown("---")
st.markdown("Developed by [Krishnendu]")
