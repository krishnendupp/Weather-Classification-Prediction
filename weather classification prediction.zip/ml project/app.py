import streamlit as st
import pandas as pd
import numpy as np
import joblib  
from sklearn.preprocessing import StandardScaler
@st.cache_resource
def load_model_and_scaler():
    model = joblib.load("C:\\Users\\User\\OneDrive\\Desktop\\New folder\\ml project\\knn_model.sav")
    scaler = joblib.load("C:\\Users\\User\\OneDrive\\Desktop\\New folder\\ml project\\scalar.sav")
    return model, scaler
model, scaler = load_model_and_scaler()
weather_classes = {
    0: "Cloudy",
    1: "Rainy",
    2: "Snowy",
    3: "Sunny"
}
st.title("Weather Classification App 🌤️")
st.markdown(
    """
    This app predicts the weather class (e.g., Sunny, Rainy, Snowy, Cloudy) based on input features.
    Fill in the values below and click 'Predict' to see the result.
    """
)

# Input features
temperature = st.number_input("Temperature (°C)", value=25.0, step=0.1)
humidity = st.number_input("Humidity (%)", value=60.0, step=0.1)
wind_speed = st.number_input("Wind Speed (km/h)", value=10.0, step=0.1)
precipitation= st.number_input("Precipitation (%)", value=85.0, step=0.1)
cloud_cover = st.number_input("Cloud Cover", value=3.0, step=0.1)
Atmospheric_Pressure = st.number_input("Atmospheric Pressure", value=1013.0, step=0.1)
uv_index = st.number_input("UV Index", value=2.0, step=0.1)
season = st.number_input("Season", value=3.0, step=0.1)
visibility = st.number_input("Visibility (km)", value=3.5, step=0.1)
location = st.number_input("Location", value=1.0, step=0.1)
if st.button("Predict"):
    input_data = np.array([[temperature, humidity, wind_speed, precipitation, cloud_cover, Atmospheric_Pressure, uv_index, season, visibility, location]])
    scaled_data = scaler.transform(input_data)
    prediction = model.predict(scaled_data)
    weather_class = weather_classes.get(prediction[0], "Unknown")
    st.subheader("Prediction Result:")
    st.write(f"The predicted weather class is: **{weather_class}**")
st.markdown("---")
st.markdown("Developed by [Krishnendu]")

